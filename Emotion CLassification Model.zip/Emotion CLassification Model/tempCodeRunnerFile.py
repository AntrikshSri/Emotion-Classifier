import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import seaborn as sns
import matplotlib.pyplot as plt

# Load and clean data
data = []
with open("test.txt", "r", encoding="utf-8") as f:
    for line in f:
        if ";" in line:
            text, emotion = line.strip().split(";")
            text = text.strip()
            emotion = emotion.strip().lower()
            if text and emotion:
                data.append({"text": text, "emotion": emotion})

df = pd.DataFrame(data)

# Check class distribution
print("Class distribution:\n", df['emotion'].value_counts())