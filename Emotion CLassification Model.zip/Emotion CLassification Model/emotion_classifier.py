import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import seaborn as sns
import matplotlib.pyplot as plt
import pickle
from sklearn.utils import resample

# Load and clean data
data = []
with open("test.txt", "r", encoding="utf-8") as f:
    for line in f:
        if ";" in line:
            text, emotion = line.strip().split(";")
            text = text.strip()
            emotion = emotion.strip().lower()
            if text and emotion:
                data.append({"text": text, "emotion": emotion})

df = pd.DataFrame(data)

# Filter out emotions with fewer than 5 samples
df = df.groupby('emotion').filter(lambda x: len(x) >= 5)

# Resample to balance classes
df_balanced = pd.DataFrame()
min_size = df['emotion'].value_counts().min()

for emotion in df['emotion'].unique():
    df_subset = df[df['emotion'] == emotion]
    df_resampled = resample(df_subset, replace=True, n_samples=min_size, random_state=42)
    df_balanced = pd.concat([df_balanced, df_resampled])

df = df_balanced.sample(frac=1).reset_index(drop=True)
print(" Balanced class distribution:\n", df['emotion'].value_counts())

# Features and labels
X = df['text']
y = df['emotion']

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

# Vectorizer
vectorizer = TfidfVectorizer(stop_words='english', lowercase=True, ngram_range=(1,2), max_df=0.95, min_df=2)
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# Train model
model = LinearSVC(class_weight='balanced', max_iter=5000)
model.fit(X_train_vec, y_train)

# Predict and evaluate
y_pred = model.predict(X_test_vec)
print("\n Classification Report:\n", classification_report(y_test, y_pred))
acc = accuracy_score(y_test, y_pred)
print(f"✅ Accuracy: {acc:.2f}")

# Save results
with open("accuracy.txt", "w") as f:
    f.write(str(acc))

with open("model.pkl", "wb") as f:
    pickle.dump(model, f)

with open("vectorizer.pkl", "wb") as f:
    pickle.dump(vectorizer, f)

# Confusion matrix
cm = confusion_matrix(y_test, y_pred, labels=model.classes_)
plt.figure(figsize=(10, 7))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=model.classes_, yticklabels=model.classes_)
plt.title(" Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("True")
plt.tight_layout()
plt.show()
