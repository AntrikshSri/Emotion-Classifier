from flask import Flask, render_template, request
import pickle
import os

# Load model and vectorizer
with open("model.pkl", "rb") as f:
    model = pickle.load(f)

with open("vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

# Load accuracy from file
accuracy = None
if os.path.exists("accuracy.txt"):
    with open("accuracy.txt", "r") as f:
        accuracy = float(f.read())

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    prediction = ""
    input_text = ""
    if request.method == "POST":
        input_text = request.form.get("text")
        if input_text:  # avoid empty string
            vectorized = vectorizer.transform([input_text])
            prediction = model.predict(vectorized)[0]
    return render_template("index.html", prediction=prediction, input_text=input_text, accuracy=accuracy)

@app.after_request
def add_header(response):
    response.cache_control.no_store = True
    return response



if __name__ == "__main__":
    app.run(debug=True)
